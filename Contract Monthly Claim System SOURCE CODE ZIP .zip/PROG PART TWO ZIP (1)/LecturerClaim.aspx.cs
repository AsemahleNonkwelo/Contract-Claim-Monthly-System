﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI.WebControls;

public partial class LecturerClaim : System.Web.UI.Page
{
    private object fileUpload;

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        // Check if the file is uploaded
        if (fileUpload.HasFile)
        {
            try
            {
                // Save the uploaded file to the server
                string fileName = Path.GetFileName(fileUpload.FileName);
                string filePath = "~/Uploads/" + fileName;
                fileUpload.SaveAs(Server.MapPath(filePath));

                // Insert claim data into the database
                string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Claims (LecturerName, HoursWorked, HourlyRate, Notes, FilePath) " +
                                   "VALUES (@LecturerName, @HoursWorked, @HourlyRate, @Notes, @FilePath)";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@LecturerName", txtLecturerName.Text);
                    cmd.Parameters.AddWithValue("@HoursWorked", Convert.ToDecimal(txtHoursWorked.Text));
                    cmd.Parameters.AddWithValue("@HourlyRate", Convert.ToDecimal(txtHourlyRate.Text));
                    cmd.Parameters.AddWithValue("@Notes", txtNotes.Text);
                    cmd.Parameters.AddWithValue("@FilePath", filePath);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                decimal hoursWorked;
                decimal hourlyRate;

                if (decimal.TryParse(txtHoursWorked.Text, out hoursWorked) && decimal.TryParse(txtHourlyRate.Text, out hourlyRate))
                {
                    // Proceed with the database logic
                }
                else
                {
                    lblMessage.Text = "Please enter valid numbers for hours worked and hourly rate.";
                }

                lblMessage.Text = "Claim submitted successfully!";
                lblMessage.ForeColor = System.Drawing.Color.Green;
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error: " + ex.Message;
            }
        }
        else
        {
            lblMessage.Text = "Please upload a document.";
        }
    }
}
