﻿USE ClaimSystemDB;

CREATE TABLE Claims (
    ClaimID INT PRIMARY KEY IDENTITY(1,1),
    LecturerName NVARCHAR(100),
    HoursWorked DECIMAL(5,2),
    HourlyRate DECIMAL(5,2),
    TotalAmount AS (HoursWorked * HourlyRate), -- Calculated column
    Notes NVARCHAR(MAX),
    Status NVARCHAR(20) DEFAULT 'Pending',
    FilePath NVARCHAR(255),
    DateSubmitted DATETIME DEFAULT GETDATE()
);
