// ClaimsVerification.aspx.cs (Code-behind)
protected void Page_Load(object sender, EventArgs e)
{
    if (!IsPostBack)
    {
        LoadClaims();
    }
}

private void LoadClaims()
{
    using (var db = new ClaimsDbContext())
    {
        var pendingClaims = db.Claims.Where(c => c.Status == "Pending").ToList();
        gvClaims.DataSource = pendingClaims;
        gvClaims.DataBind();
    }
}

protected void btnApprove_Click(object sender, EventArgs e)
{
    int claimId = Convert.ToInt32(((Button)sender).CommandArgument);
    UpdateClaimStatus(claimId, "Approved");
}

protected void btnReject_Click(object sender, EventArgs e)
{
    int claimId = Convert.ToInt32(((Button)sender).CommandArgument);
    UpdateClaimStatus(claimId, "Rejected");
}

private void UpdateClaimStatus(int claimId, string status)
{
    using (var db = new ClaimsDbContext())
    {
        var claim = db.Claims.FirstOrDefault(c => c.Id == claimId);
        if (claim != null)
        {
            claim.Status = status;
            db.SaveChanges();
        }
    }
}
