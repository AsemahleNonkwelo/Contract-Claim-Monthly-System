﻿using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.WebControls;
using System;

protected void Page_Load(object sender, EventArgs e)
{
    if (!IsPostBack)
    {
        LoadClaims();
    }
}

private void LoadClaims()
{
    string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
    using (SqlConnection conn = new SqlConnection(connectionString))
    {
        string query = "SELECT * FROM Claims WHERE Status = 'Pending'";
        SqlDataAdapter da = new SqlDataAdapter(query, conn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        gvClaims.DataSource = dt;
        gvClaims.DataBind();
    }
}

protected void btnApprove_Click(object sender, EventArgs e)
{
    Button btn = (Button)sender;
    int claimId = Convert.ToInt32(btn.CommandArgument);
    UpdateClaimStatus(claimId, "Approved");
}

protected void btnReject_Click(object sender, EventArgs e)
{
    Button btn = (Button)sender;
    int claimId = Convert.ToInt32(btn.CommandArgument);
    UpdateClaimStatus(claimId, "Rejected");
}

private void UpdateClaimStatus(int claimId, string status)
{
    string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
    using (SqlConnection conn = new SqlConnection(connectionString))
    {
        string query = "UPDATE Claims SET Status = @Status WHERE ClaimID = @ClaimID";
        SqlCommand cmd = new SqlCommand(query, conn);
        cmd.Parameters.AddWithValue("@Status", status);
        cmd.Parameters.AddWithValue("@ClaimID", claimId);

        conn.Open();
        cmd.ExecuteNonQuery();
    }
    LoadClaims(); // Refresh the claim list after update
}
