using System;

namespace ContractMonthlyClaimSystem 
{
    public partial class LecturerView : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Initialization logic if needed
            }
        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                // Retrieve input values
                decimal hoursWorked = Convert.ToDecimal(txtHoursWorked.Text);
                decimal hourlyRate = Convert.ToDecimal(txtHourlyRate.Text);

                // Calculate total claim amount
                decimal totalClaim = hoursWorked * hourlyRate;

                // Display the calculated amount
                lblTotalClaim.Text = totalClaim.ToString("C");
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error: " + ex.Message;
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                // Example: Save the claim details to the database
                string lecturerId = "Lecturer001"; // Replace with the logged-in lecturer's ID
                decimal hoursWorked = Convert.ToDecimal(txtHoursWorked.Text);
                decimal hourlyRate = Convert.ToDecimal(txtHourlyRate.Text);
                decimal totalClaim = hoursWorked * hourlyRate;

                // Save data (example using Entity Framework)
                using (var db = new ClaimsDbContext())
                {
                    var claim = new Claim
                    {
                        LecturerId = lecturerId,
                        HoursWorked = hoursWorked,
                        HourlyRate = hourlyRate,
                        TotalClaimAmount = totalClaim,
                        Status = "Pending"
                    };

                    db.Claims.Add(claim);
                    db.SaveChanges();
                }

                lblMessage.Text = "Claim submitted successfully!";
                lblMessage.ForeColor = System.Drawing.Color.Green;
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error: " + ex.Message;
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}
