// HRReport.aspx.cs (Code-behind)
protected void Page_Load(object sender, EventArgs e)
{
    if (!IsPostBack)
    {
        LoadApprovedClaims();
    }
}

private void LoadApprovedClaims()
{
    using (var db = new ClaimsDbContext())
    {
        var approvedClaims = db.Claims.Where(c => c.Status == "Approved").ToList();
        gvApprovedClaims.DataSource = approvedClaims;
        gvApprovedClaims.DataBind();
    }
}
